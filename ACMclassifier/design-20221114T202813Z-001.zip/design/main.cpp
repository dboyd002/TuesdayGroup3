#include <iostream>
#include <bits/stdc++.h>

using namespace std;

int main()
{
    ///Declare variables
    string line;

    ///text for a string
    line = "This is a test test line line line line line line";

    ///vector to save tokens
    vector <string> tokens;

    ///use stringstream for tokenizing
    stringstream readline(line);

    ///string for tokenizing
    string text;

    ///use a loop for tokens
    while(getline(readline, text, ' '))
    {
        tokens.push_back(text);
    }

    ///Print the vector
    for(int a = 0; a < tokens.size(); a++)
    {
        cout << tokens[a] << '\n';
    }

    ///count total words
    int words = 0;

    ///store token size in a variable
    int wsize = line.size();

    ///use a loop for counting
    for(int s = 0; s < wsize; s++)
    {
        ///if there is a space, increase the word count
        if(line[s] == ' ')
        {
            words++;
        }
    }
        ///increase the word count by 1 after the loop
        words = words + 1;

        ///print the word count
        cout << endl << "Number of words: " << words << endl << endl;

        ///get the frequency
        string freq = "";
        map<string, int> D;

        ///use a loop for getting the frequency
        for(int b = 0; b < line.size(); b++)
        {
            ///if there is a space, there is a word
            if(line[b] == ' ')
            {
                ///if the word is not repeated, it is used once
                if(D.find(freq) == D.end())
                {
                    D.insert(make_pair(freq, 1));
                    freq = "";
                }

                ///if a word is found, update the frequency
                else
                {
                    D[freq]++;
                    freq = "";
                }
            }

            else
            {
                freq += line[b];
            }
        }

    /// store the last word
    if (D.find(freq) == D.end())
    {
        D.insert(make_pair(freq, 1));
    }

    ///update the frequency
    else
    {
        D[freq]++;
    }

    /// read the map to print the  frequency
    for (auto& it : D)
        {
            cout << it.first << " = " << it.second << endl;
        }
    }
